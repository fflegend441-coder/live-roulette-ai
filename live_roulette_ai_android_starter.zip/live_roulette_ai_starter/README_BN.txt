LIVE ROULETTE AI — Android starter project

গুরুত্বপূর্ণ:
- এটি APK নয়; Android Studio/Gradle দিয়ে build করার জন্য starter source project।
- এই পরিবেশে Android SDK দিয়ে APK compile/verify করা হয়নি।
- Screen capture ও overlay permission পাওয়া গেলেও roulette-এর ফল আগে থেকে জানা যায় না।
- এই starter-এ UI ও permission flow আছে; OCR-based live result extraction এখনো যুক্ত/পরীক্ষিত নয়।
- Google Play / casino app-এর security বা terms এড়িয়ে যাওয়ার কোনো ব্যবস্থা নেই।

Build:
1. ZIP extract করুন।
2. Android Studio-তে folder open করুন।
3. Gradle sync শেষ হলে Build > Build Bundle(s) / APK(s) > Build APK(s)।
4. app/build/outputs/apk/debug/app-debug.apk তৈরি হলে ফোনে install করুন।

ফোনে শুধু ZIP extract করলেই APK হবে না; Android SDK/Gradle build environment প্রয়োজন।
