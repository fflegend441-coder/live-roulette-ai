package com.example.liveroulette

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 32, 28, 32)
            setBackgroundColor(Color.rgb(16, 24, 32))
        }

        fun text(value: String, size: Float, color: Int): TextView =
            TextView(this).apply {
                text = value
                textSize = size
                setTextColor(color)
                gravity = Gravity.CENTER
                setPadding(8, 12, 8, 12)
            }

        page.addView(text("LIVE ROULETTE AI", 24f, Color.WHITE))
        status = text("READY — analysis is not running", 15f, Color.GREEN)
        page.addView(status)

        page.addView(text("NEXT PREDICTION: --", 22f, Color.WHITE))
        page.addView(text("Roulette outcomes are random. No number can be guaranteed.", 13f, Color.LTGRAY))

        val permission = Button(this).apply {
            text = "Allow floating panel permission"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else {
                    Toast.makeText(this@MainActivity, "Overlay permission is allowed", Toast.LENGTH_SHORT).show()
                }
            }
        }
        page.addView(permission, matchWrap())

        val start = Button(this).apply {
            text = "START DEMO"
            setOnClickListener {
                status.text = "DEMO ACTIVE — no live screen reading yet"
                Toast.makeText(this@MainActivity,
                    "This starter does not yet read the game screen.", Toast.LENGTH_LONG).show()
            }
        }
        page.addView(start, matchWrap())

        val stop = Button(this).apply {
            text = "STOP"
            setOnClickListener { status.text = "STOPPED" }
        }
        page.addView(stop, matchWrap())

        setContentView(page)
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = 8 }
}
