IMMERSIVE ROULETTE AI — ANDROID SOURCE

ফিচার:
- Immersive Roulette নির্বাচন করা আছে
- Android screen-capture permission নিয়ে স্ক্রিনে দৃশ্যমান লেখা ML Kit OCR দিয়ে পড়ে
- Floating panel-এ সর্বশেষ শনাক্ত সংখ্যা ও সাম্প্রতিক history দেখায়
- STOP DETECTION দিয়ে capture বন্ধ করা যায়

সীমাবদ্ধতা ও নিরাপত্তা:
- এটি কোনো নিশ্চিত predictor নয়; roulette ফলাফল random.
- OCR স্ক্রিনের অন্য সংখ্যা ভুল করে ফলাফল হিসেবে ধরতে পারে। History যাচাই করুন।
- Casino game-এর UI/layout অনুযায়ী OCR নির্ভুলতা আলাদা হবে; এই starter নির্দিষ্ট ফলাফল বোর্ড crop/template দিয়ে tune করা হয়নি।
- Screen capture চালু হলে Android-এর নিজস্ব permission prompt আসবে এবং foreground notification দেখা যাবে।
- Google Play / casino app policy ও local law মেনে ব্যবহার করুন।

Build:
GitHub Actions workflow `.github/workflows/android.yml` push করলে APK build করে artifact আপলোড করবে.
