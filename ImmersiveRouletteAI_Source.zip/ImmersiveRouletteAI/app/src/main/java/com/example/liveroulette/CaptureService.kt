package com.example.liveroulette

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import androidx.annotation.Keep
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque
import java.util.regex.Pattern

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "projection_result_code"
        const val EXTRA_RESULT_DATA = "projection_result_data"
        private const val CHANNEL_ID = "roulette_capture"
        private const val NOTIFICATION_ID = 73
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var worker: HandlerThread? = null
    private var workerHandler: Handler? = null
    private var overlay: TextView? = null
    private var busy = false
    private var lastNumber: Int? = null
    private var lastSeenAt = 0L
    private val history = ArrayDeque<Int>()
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val numberPattern = Pattern.compile("(?<![0-9])(?:[0-9]|[1-2][0-9]|3[0-6])(?![0-9])")

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
        createOverlay()
        worker = HandlerThread("roulette-screen-reader").also { it.start() }
        workerHandler = Handler(worker!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data = getProjectionData(intent)
        if (code == 0 || data == null) { stopSelf(); return START_NOT_STICKY }
        try {
            val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(code, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, workerHandler)
            startReader()
        } catch (e: Exception) {
            updatePanel("Could not start screen reading\n${e.javaClass.simpleName}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    @Suppress("DEPRECATION")
    private fun getProjectionData(intent: Intent?): Intent? {
        return if (Build.VERSION.SDK_INT >= 33) {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
        } else {
            intent?.getParcelableExtra(EXTRA_RESULT_DATA) as? Intent
        }
    }

    private fun buildNotification(): Notification {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL_ID, "Roulette screen reader", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("Immersive Roulette AI")
            .setContentText("Reading the screen for visible roulette results")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .setOngoing(true).build()
    }

    private fun startReader() {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        val display = (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay
        @Suppress("DEPRECATION")
        display.getRealMetrics(metrics)
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        val density = metrics.densityDpi
        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        imageReader?.setOnImageAvailableListener({ reader ->
            val image = try { reader.acquireLatestImage() } catch (_: Exception) { null }
            if (image != null) processImage(image)
        }, workerHandler)
        virtualDisplay = projection?.createVirtualDisplay(
            "RouletteOCR", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface, null, workerHandler
        )
        updatePanel("IMMERSIVE ROULETTE\nAuto detection: ON\nWaiting for a visible result…")
    }

    private fun processImage(image: Image) {
        if (busy) { image.close(); return }
        busy = true
        val bitmap = imageToBitmap(image)
        image.close()
        if (bitmap == null) { busy = false; return }
        val input = InputImage.fromBitmap(bitmap, 0)
        recognizer.process(input)
            .addOnSuccessListener { result ->
                val matcher = numberPattern.matcher(result.text)
                val found = mutableListOf<Int>()
                while (matcher.find()) {
                    val n = matcher.group()?.toIntOrNull()
                    if (n != null && n in 0..36) found.add(n)
                }
                // Use the last recognized number on the screen. OCR can misread other UI numbers;
                // users should verify the history against the actual roulette result.
                val candidate = found.lastOrNull()
                if (candidate != null) acceptCandidate(candidate)
            }
            .addOnCompleteListener {
                bitmap.recycle()
                busy = false
            }
    }

    private fun imageToBitmap(image: Image): Bitmap? {
        return try {
            val plane = image.planes[0]
            val buffer = plane.buffer
            val pixelStride = plane.pixelStride
            val rowStride = plane.rowStride
            val rowPadding = rowStride - pixelStride * image.width
            val paddedWidth = image.width + rowPadding / pixelStride
            val full = Bitmap.createBitmap(paddedWidth, image.height, Bitmap.Config.ARGB_8888)
            buffer.rewind()
            full.copyPixelsFromBuffer(buffer)
            val cropped = Bitmap.createBitmap(full, 0, 0, image.width, image.height)
            full.recycle()
            cropped
        } catch (_: Exception) { null }
    }

    private fun acceptCandidate(number: Int) {
        val now = System.currentTimeMillis()
        // Ignore repeated OCR frames for the same displayed result; a new result can be added
        // after the screen changes or after a short cooldown.
        if (number == lastNumber && now - lastSeenAt < 12000L) return
        lastNumber = number
        lastSeenAt = now
        history.addFirst(number)
        while (history.size > 12) history.removeLast()
        val list = history.toList()
        val color = when {
            number == 0 -> "GREEN"
            number in redNumbers -> "RED"
            else -> "BLACK"
        }
        val oddEven = when { number == 0 -> "ZERO"; number % 2 == 0 -> "EVEN"; else -> "ODD" }
        val historyText = list.joinToString("  •  ")
        updatePanel("IMMERSIVE ROULETTE\nLatest OCR: $number ($color / $oddEven)\nHistory (newest first):\n$historyText\n\nOCR may misread screen text. Verify each result.")
    }

    private val redNumbers = setOf(1,3,5,7,9,12,14,16,18,19,21,23,25,27,30,32,34,36)

    private fun createOverlay() {
        if (Build.VERSION.SDK_INT >= 23 && !android.provider.Settings.canDrawOverlays(this)) return
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = overlayWindowType()
        overlay = TextView(this).apply {
            text = "IMMERSIVE ROULETTE AI\nWaiting to start…"
            textSize = 13f
            setTextColor(0xFFFFFFFF.toInt())
            setBackgroundColor(0xE6223444.toInt())
            setPadding(18, 14, 18, 14)
        }
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = 12; y = 120 }
        try { wm.addView(overlay, params) } catch (_: Exception) { overlay = null }
    }

    @Suppress("DEPRECATION")
    private fun overlayWindowType(): Int = if (Build.VERSION.SDK_INT >= 26) {
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
    } else {
        WindowManager.LayoutParams.TYPE_PHONE
    }

    private fun updatePanel(message: String) {
        val view = overlay ?: return
        view.post { view.text = message }
    }

    override fun onDestroy() {
        try { virtualDisplay?.release() } catch (_: Exception) {}
        try { imageReader?.close() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        try { overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) } } catch (_: Exception) {}
        overlay = null
        worker?.quitSafely()
        recognizer.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
