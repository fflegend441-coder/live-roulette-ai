package com.example.liveroulette

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var status: TextView
    private lateinit var gamePicker: Spinner
    private val captureRequest = 4102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 32, 28, 32)
            setBackgroundColor(0xFF101820.toInt())
        }
        fun label(value: String, size: Float, color: Int = 0xFFFFFFFF.toInt()) = TextView(this).apply {
            text = value; textSize = size; setTextColor(color); setPadding(4, 12, 4, 12)
        }
        root.addView(label("IMMERSIVE ROULETTE AI", 23f))
        root.addView(label("Choose game", 15f, 0xFFB8C7D1.toInt()))
        gamePicker = Spinner(this)
        gamePicker.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item,
            listOf("Immersive Roulette"))
        root.addView(gamePicker)
        status = label("STATUS: READY", 16f, 0xFF70E090.toInt())
        root.addView(status)

        root.addView(Button(this).apply {
            text = "1. ALLOW FLOATING PANEL"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else Toast.makeText(this@MainActivity, "Overlay permission already allowed", Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text = "2. START AUTO DETECTION"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    status.text = "Allow floating permission first"; return@setOnClickListener
                }
                val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(manager.createScreenCaptureIntent(), captureRequest)
            }
        })
        root.addView(Button(this).apply {
            text = "STOP DETECTION"
            setOnClickListener {
                stopService(Intent(this@MainActivity, CaptureService::class.java))
                status.text = "STATUS: STOPPED"
            }
        })
        root.addView(label("OCR reads visible on-screen numbers only. Check the history for mistakes.", 13f, 0xFFB8C7D1.toInt()))
        root.addView(label("Roulette is random. Statistics cannot predict or guarantee the next result.", 12f, 0xFFFFD18A.toInt()))
        setContentView(root)
    }

    @Deprecated("Legacy result callback is used for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == captureRequest && resultCode == RESULT_OK && data != null) {
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) startForegroundService(serviceIntent)
            else startService(serviceIntent)
            status.text = "STATUS: SCREEN READING STARTED"
        } else if (requestCode == captureRequest) {
            status.text = "SCREEN CAPTURE PERMISSION NOT GRANTED"
        }
    }
}
