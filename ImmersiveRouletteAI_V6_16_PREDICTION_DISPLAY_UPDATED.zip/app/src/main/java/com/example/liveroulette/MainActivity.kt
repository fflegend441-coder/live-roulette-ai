package com.example.liveroulette

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    companion object {
        private const val REQUEST_OVERLAY = 4101
        private const val REQUEST_CAPTURE = 4102
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val ACTION_STOP = "com.example.liveroulette.STOP_CAPTURE"
    }

    private lateinit var projectionManager: MediaProjectionManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS) != android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4103)
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }

        val title = TextView(this).apply {
            text = "Roulette OCR Assistant"
            textSize = 23f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val info = TextView(this).apply {
            text = "প্রথমে Floating Panel ও 1xBet App Detection permission দিন। তারপর Start চাপুন। STAR ON করলে শুধু 1xBet সামনে থাকলেই History Scan হবে।"
            textSize = 16f
            gravity = Gravity.CENTER
            setPadding(0, 0, 0, 24)
        }
        val allowButton = Button(this).apply {
            text = "ALLOW FLOATING PANEL"
            setOnClickListener { requestOverlayPermission() }
        }
        val usageButton = Button(this).apply {
            text = "ALLOW 1XBET APP DETECTION"
            setOnClickListener {
                try {
                    startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                } catch (_: Exception) {
                    Toast.makeText(this@MainActivity, "Usage Access Settings খোলা যায়নি", Toast.LENGTH_LONG).show()
                }
            }
        }
        val startButton = Button(this).apply {
            text = "START ON • LIVE SCAN"
            setOnClickListener { startCaptureFlow() }
        }
        val stopButton = Button(this).apply {
            text = "STOP OFF • LIVE SCAN"
            setOnClickListener {
                val stopIntent = Intent(this@MainActivity, CaptureService::class.java).apply {
                    action = ACTION_STOP
                }
                startService(stopIntent)
                Toast.makeText(this@MainActivity, "Panel বন্ধ করার অনুরোধ পাঠানো হয়েছে", Toast.LENGTH_SHORT).show()
            }
        }

        layout.addView(title)
        layout.addView(info)
        layout.addView(allowButton)
        layout.addView(usageButton)
        layout.addView(startButton)
        layout.addView(stopButton)
        setContentView(layout)
    }

    private fun requestOverlayPermission() {
        if (Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Floating permission already allowed", Toast.LENGTH_SHORT).show()
            return
        }
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        startActivityForResult(intent, REQUEST_OVERLAY)
    }

    private fun startCaptureFlow() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "আগে ALLOW FLOATING PANEL চাপুন", Toast.LENGTH_LONG).show()
            requestOverlayPermission()
            return
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQUEST_CAPTURE)
    }

    @Deprecated("Legacy result callback is used for broad Android compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OVERLAY) {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permission allowed", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Floating permission দেওয়া হয়নি", Toast.LENGTH_SHORT).show()
            }
            return
        }
        if (requestCode == REQUEST_CAPTURE) {
            if (resultCode != RESULT_OK || data == null) {
                Toast.makeText(this, "Screen capture permission দেওয়া হয়নি", Toast.LENGTH_LONG).show()
                return
            }
            val serviceIntent = Intent(this, CaptureService::class.java).apply {
                putExtra(EXTRA_RESULT_CODE, resultCode)
                putExtra(EXTRA_RESULT_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(serviceIntent)
            } else {
                startService(serviceIntent)
            }
            Toast.makeText(this, "Floating panel চালু হয়েছে", Toast.LENGTH_SHORT).show()
        }
    }
}
